const teacherRegButton = document.getElementById("teacherReg");
teacherRegButton.addEventListener("click", ()=>{
    window.location.href = "./teacher_reg/";
})
const studentRegButton = document.getElementById("studentReg");
studentRegButton.addEventListener("click", ()=>{
    window.location.href = "./student_reg";
})
const parentRegButton = document.getElementById("parentReg");
parentRegButton.addEventListener("click", ()=>{
    window.location.href = "./parent_reg";
})
const ntstaffRegButton = document.getElementById("ntstaffReg");
ntstaffRegButton.addEventListener("click", ()=>{
    window.location.href = "./ntstaff_reg";
})
const teacherEnrollButton = document.getElementById("teacherEnroll");
teacherEnrollButton.addEventListener("click", ()=>{
    window.location.href = "usrmng/t_enroll.html";
})
const studentEnroll = document.getElementById("studentEnroll");
studentEnroll.addEventListener("click", ()=>{
    window.location.href = "usrmng/s_enroll.html";
})
const parentEnrollButton = document.getElementById("parentEnroll");
parentEnrollButton.addEventListener("click", ()=>{
    window.location.href = "usrmng/p_enroll.html";
})
const ntstaffEnroll = document.getElementById("ntstaffEnroll");
ntstaffEnroll.addEventListener("click", ()=>{
    window.location.href = "usrmng/nt_enroll.html";
})
const teacherMngButton = document.getElementById("teacherMng");
teacherMngButton.addEventListener("click", ()=>{
    window.location.href = "usrmng/t_manage.html";
})
const studentMngButton = document.getElementById("studentMng");
studentMngButton.addEventListener("click", ()=>{
    window.location.href = "usrmng/s_manage.html";
})
const ntstaffMngButton = document.getElementById("ntstaffMng");
ntstaffMngButton.addEventListener("click", ()=>{
    window.location.href = "usrmng/nt_manage.html";
})
const parentMngButton = document.getElementById("parentMng");
parentMngButton.addEventListener("click", ()=>{
    window.location.href = "usrmng/p_manage.html"
})
//link active toggle
function T2(){
    /*activate the classlist*/
    document.querySelector(".sidebar a.active")?.classList.remove("active");
    document.querySelectorAll(".sidebar a")[1].classList.add("active");
}
T2();